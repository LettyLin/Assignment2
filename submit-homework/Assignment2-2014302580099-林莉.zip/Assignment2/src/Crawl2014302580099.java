import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by LinLi on 2015/10/18.
 */
public class Crawl2014302580099 {
    public static void main(String[] args) throws IOException{
        CrawlTheTeacher();
    }

    public static void CrawlTheTeacher() throws IOException {
        String[] string = new String[5];
        String url = "http://my.chd.edu.cn/pei";
        org.jsoup.nodes.Document doc = Jsoup.parse(new URL(url).openStream(), "utf-8", url);
        String[] title = doc.title().split("\\|");
        string[0] = "姓名: " + title[0];
        Element introduction = doc.getElementsByAttributeValue("class", "boder h225").get(2);
        string[1] = "\n" + introduction.text().replaceAll(Jsoup.parse("&nbsp").text(), "");

        Element area = doc.getElementsByAttributeValue("class", "boder h225").get(3);
        string[2] = "\n" + area.text().replaceAll(Jsoup.parse("&nbsp").text(), "");

        Pattern pattern1 = Pattern.compile("[0-9]{3}\\-?[0-9]+");
        Matcher matcher1 = pattern1.matcher(doc.text());
        if (matcher1.find()) {
            string[3] = "联系方式: " + matcher1.group();
        }

        Pattern pattern2 = Pattern.compile("[0-9a-zA-Z]+@[0-9a-zA-Z]+.[a-z]+");
        Matcher matcher2 = pattern2.matcher(doc.text());
        if (matcher2.find()) {
            string[4] = "\n邮箱: " + matcher2.group();
        }

        try {
            File file = new File("TheTeacherPei'sInformation.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter filewriter = new FileWriter(file);
            BufferedWriter bufferwriter = new BufferedWriter(filewriter);
            for (int i = 0; i < string.length; i++) {
                bufferwriter.write(string[i]+"\r\n");
            }
            bufferwriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.print("Done");
    }
}